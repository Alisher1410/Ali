import 'package:flutter/material.dart';

class LoginScreen extends StatelessWidget {
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.send, size: 60, color: Colors.blue),
            SizedBox(height: 20),
            TextField(controller: phoneController, decoration: InputDecoration(labelText: 'Telefon raqam')),
            TextField(controller: passwordController, decoration: InputDecoration(labelText: 'Parol'), obscureText: true),
            SizedBox(height: 20),
            ElevatedButton(child: Text('Kirish'), onPressed: () { Navigator.pushNamed(context, '/chat'); }),
          ],
        ),
      ),
    );
  }
}
