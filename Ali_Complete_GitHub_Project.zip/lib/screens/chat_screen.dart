import 'package:flutter/material.dart';

class ChatScreen extends StatelessWidget {
  final TextEditingController messageController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Ali Messenger')),
      body: Column(
        children: [
          Expanded(child: Container()),
          Padding(
            padding: EdgeInsets.all(8),
            child: Row(
              children: [
                IconButton(icon: Icon(Icons.emoji_emotions), onPressed: () {}),
                Expanded(child: TextField(controller: messageController, decoration: InputDecoration(hintText: 'Xabar yozing'))),
                IconButton(icon: Icon(Icons.mic), onPressed: () {}),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
